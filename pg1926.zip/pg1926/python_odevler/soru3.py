liste = [2,4,1,6,4,0,0]
print(liste)
liste[0]=0
liste[1]=0
liste[2]=1
liste[3]=2
liste[4]=4
liste[5]=4
liste[6]=6
print(liste)
