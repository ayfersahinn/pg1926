<html>
<head>
<title>mükemmel sayı</title>
</head>

<body>


<?php

$toplam = 0;
for($i=1; $i<$_GET["sayi"]; $i+=1)
{
    if($_GET["sayi"] % $i == 0)
    {
        $toplam += $i;
    }

}
if($toplam == $_GET["sayi"])
{
    $a = "<script> alert('Girilen sayı mükemmel sayıdır.') </script>";
    echo $a;
}
else
{
    $b = "<script> alert('Girilen sayı mükemmel sayı değildir.') </script>";
    echo $b;
}


?>
</body>
</html>