<html>
<head>
<title>mükemmel sayı</title>
</head>

<body>

<form action="result.php" method="get">
<label >Bir sayı giriniz:</label>
<input type="text" id="number" name="sayi">
<button type="submit">Gönder</button>

</form>

</body>
</html>