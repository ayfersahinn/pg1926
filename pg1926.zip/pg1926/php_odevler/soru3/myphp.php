<!DOCTYPE html>
<html>
<body>

<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
  Sayi Girin: <input type="text" name="sayi">
  <input type="submit">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
	$sayac = 0;
	for($i = 2; $i < $_POST["sayi"]; $i++)
	{
		if($_POST["sayi"] % $i == 0)
			$sayac = 1;
	}
	
	if($sayac == 0)
		echo "Asal sayi";
	else
		echo "Asal sayi değil";
}
?>

</body>
</html>