<?php
date_default_timezone_set("Europe/Istanbul");
$tarih = strtotime("now");
$d = date("G",$tarih);

if($d>6 && $d<=10)
{
    echo "Günaydın";
}
else if($d>10 && $d<=17)
{
    echo "İyi günler";
}
else if($d>17 && $d<=20)
{
    echo "İyi akşamlar";
}
else if($d>20 && $d<=23)
{
    echo "İyi geceler";
}
else if($d>=0 && $d<=6)
{
    echo "Esenlikler dilerim";
}



?>